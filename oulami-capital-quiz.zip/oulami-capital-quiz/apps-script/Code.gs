/**
 * OULAMI 국기로 수도 맞히기 — 구글 시트 기록 저장용 스크립트
 *
 * 1) 아래 ADMIN_PIN을 동아리 운영진만 아는 비밀번호로 바꾸세요.
 * 2) 배포 > 새 배포 > 웹 앱 (실행: 나, 액세스 권한: 모든 사용자) 로 배포하세요.
 * 3) 받은 웹 앱 주소를 index.html의 SHEET_URL에 붙여 넣으세요.
 */
const ADMIN_PIN = "oulami30";      // ← 꼭 바꾸세요
const SHEET_NAME = "참가자";
const HEADERS = ["id", "참여시각", "학과", "학번", "이름", "전화번호", "점수", "정답수", "소요(ms)", "문제별 결과"];

function sheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(HEADERS);
    sh.setFrozenRows(1);
    sh.getRange("F:F").setNumberFormat("@");   // 전화번호 앞자리 0 유지
    sh.getRange("D:D").setNumberFormat("@");
  }
  return sh;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function mask_(p) {
  const d = String(p || "").replace(/\D/g, "");
  return d.length >= 10 ? d.slice(0, 3) + "-****-" + d.slice(-4) : "";
}

function clean_(v, max) {
  return String(v == null ? "" : v).slice(0, max);
}

function doGet() {
  return json_({ ok: true, service: "oulami-capital-quiz" });
}

function doPost(e) {
  let body;
  try { body = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: "bad_request" }); }
  const isAdmin = !!body.pin && body.pin === ADMIN_PIN;

  if (body.action === "add") {
    const r = body.record || {};
    const id = clean_(r.id, 40);
    if (!id) return json_({ ok: false, error: "bad_request" });
    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      const sh = sheet_();
      const ids = sh.getLastRow() > 1 ? sh.getRange(2, 1, sh.getLastRow() - 1, 1).getValues().flat() : [];
      if (ids.indexOf(id) === -1) {            // 재전송돼도 한 번만 기록
        const answers = (r.answers || []).map(a => (a.ok ? "O " : "X ") + clean_(a.c, 20)).join(", ");
        sh.appendRow([id, clean_(r.at, 40), clean_(r.dept, 30), clean_(r.sid, 12), clean_(r.name, 20), clean_(r.phone, 13),
          Number(r.score) || 0, Number(r.correct) || 0, Number(r.durationMs) || 0, answers]);
      }
    } finally { lock.releaseLock(); }
    return json_({ ok: true });
  }

  if (body.action === "list") {
    const sh = sheet_();
    const n = sh.getLastRow() - 1;
    const rows = n > 0 ? sh.getRange(2, 1, n, 9).getValues() : [];
    const entries = rows.filter(r => r[0]).map(r => ({
      id: String(r[0]), at: String(r[1]), dept: String(r[2]), sid: String(r[3]), name: String(r[4]),
      phone: isAdmin ? String(r[5]) : mask_(r[5]),
      score: Number(r[6]) || 0, correct: Number(r[7]) || 0, durationMs: Number(r[8]) || 0
    }));
    return json_({ ok: true, admin: isAdmin, entries: entries });
  }

  if (body.action === "delete") {
    if (!isAdmin) return json_({ ok: false, error: "forbidden" });
    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      const sh = sheet_();
      const n = sh.getLastRow() - 1;
      if (n > 0) {
        const ids = sh.getRange(2, 1, n, 1).getValues().flat().map(String);
        const i = ids.indexOf(String(body.id));
        if (i !== -1) sh.deleteRow(i + 2);
      }
    } finally { lock.releaseLock(); }
    return json_({ ok: true });
  }

  return json_({ ok: false, error: "unknown_action" });
}
